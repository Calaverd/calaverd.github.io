love.window.setTitle("No Shader Palette Swap")
love.window.setMode(512,512)


local image_data = nil
local image_map = nil
local palette_data = nil
local image = nil

local use_palette = 1
local max_palettes = 0
local look_up_color_table = nil

function love.load()
    image_map = love.image.newImageData('ima.png')
    image_data = love.image.newImageData( image_map:getWidth(), image_map:getHeight())
	palette_data = love.image.newImageData('palette.png')
	
    max_palettes = palette_data:getHeight()
    
	look_up_color_table = {}
	local col = palette_data:getWidth()
	local i = 0
    while i < col do
        local r,g,b,a = palette_data:getPixel(i,0)
        local id = ("%X_%X_%X_%X"):format(math.floor((r)*255),math.floor((g)*255), math.floor((b)*255),math.floor((a)*255))  
        look_up_color_table[id] = i
        i=i+1
    end
    
    use_palette = 1
    changePalete()
end

function changePalete()
    image_data:mapPixel(changeColors)
    image = love.graphics.newImage(image_data)
    image:setFilter('nearest','nearest')
end


function changeColors(x, y, r,g,b,a)
    local o_r,o_g,o_b,o_a = image_map:getPixel(x,y)
    local id = ("%X_%X_%X_%X"):format(math.floor((o_r)*255),math.floor((o_g)*255), math.floor((o_b)*255),math.floor((o_a)*255))
    
	--check if the color exist on the table
    if look_up_color_table[id] then
        
		local col = look_up_color_table[id]
        local row = use_palette-1
        return palette_data:getPixel(col,row)
    end
	
	return r, g, b, a
end

function love.update(dt)
    if dt < 1/60 then
        love.timer.sleep(dt-1/60)
    end
end


function love.draw()    
    love.graphics.setBackgroundColor(0.5,0.5,0.5)
    
    love.graphics.setColor(0,0,0)
    love.graphics.print('Use the arrow keys to change the palette ',128,100)
	love.graphics.rectangle('line',128,128,256,256)
    
    love.graphics.setColor(1,1,1)
    love.graphics.draw(image,128,128,0,4,4)
end

function love.keypressed(key)
    if key == 'left' or key == 'up' then
        use_palette = use_palette - 1
    elseif key == 'right' or key == 'down' then
        use_palette = use_palette + 1
    end
    use_palette = math.min(math.max(use_palette,1),max_palettes)
    changePalete()
end