--[[
CORE - Colección de funciones utiles para manejar juegos.

Cambios:BXOR a cambiado a una version más rapida

--]]

---binary xor logical door by Arno Wagner 
function bxor(x, y)
   local z = 0
   for i = 0, 31 do
      if (x % 2 == 0) then                      -- x had a '0' in bit i
         if ( y % 2 == 1) then                  -- y had a '1' in bit i
            y = y - 1 
            z = z + 2 ^ i                       -- set bit i of z to '1' 
         end
      else                                      -- x had a '1' in bit i
         x = x - 1
         if (y % 2 == 0) then                  -- y had a '0' in bit i
            z = z + 2 ^ i                       -- set bit i of z to '1' 
         else
            y = y - 1 
         end
      end
      y = y / 2
      x = x / 2
   end
   return z
end


--oveloaded functions
function Overloaded()
    local fns = {}
    local mt = {}
    
    local function oerror()
        return error("Invalid argument types to overloaded function")
    end
    
    function mt:__call(...)
        local arg = {...}
        local default = self.default
        
        local signature = {}
        for i,arg in ipairs {...} do
            signature[i] = type(arg)
        end
        
        signature = table.concat(signature, ",")
        
        return (fns[signature] or self.default)(...)
    end
    
    function mt:__index(key)
        local signature = {}
        local function __newindex(self, key, value)
            print(key, type(key), value, type(value))
            signature[#signature+1] = key
            fns[table.concat(signature, ",")] = value
            print("bind", table.concat(signature, ", "))
        end
        local function __index(self, key)
            print("I", key, type(key))
            signature[#signature+1] = key
            return setmetatable({}, { __index = __index, __newindex = __newindex })
        end
        return __index(self, key)
    end
    
    function mt:__newindex(key, value)
        fns[key] = value
    end
    
    return setmetatable({ default = oerror }, mt)
end




---
function testbflag(set, flag)
  return set % (2*flag) >= flag
end

function setbflag(set, flag)
  if set % (2*flag) >= flag then
    return set
  end
  return set + flag
end

function clrbflag(set, flag) -- clear flag
  if set % (2*flag) >= flag then
    return set - flag
  end
  return set
end



--interolación lineal.
function lerp(a,b,t) return (1-t)*a + t*b end

--[[
Clase vector2D
]]
function Vector2D(x,y)
    local self = {x = x or 0,y= y or 0}
    
    function self.magnitud()
      return math.sqrt(self.x*self.x+self.y*self.y) or 0
    end
    
    function self.magnitudCuadrada()
      return self.x*self.x+self.y*self.y or 0
    end
    
    function self.productoPunto(vec)
      --print(self.x,self.y)
      --print(vec.x,vec.y)
      return self.x*vec.x + self.y*vec.y
    end
    
    function self.productoCruz(vec)
      --print(self.x,self.y)
      --print(vec.x,vec.y)
      return self.x*vec.y - self.y*vec.x
    end
    
    function self.lerpVector(vec,t)
        local t = t or 0.5
        self.x = lerp(vec.x,self.x,t)
        self.y = lerp(vec.y,self.y,t)
    end
    
    function self.normalizar(min)
      local min = min or 0
      local mag = self.magnitud()
      if mag > min  then
        return self/mag
      end
      return Vector2D(0,0)
    end
    --sobrecarga de operadores...
    local mt = {
    __add = function (lhs, rhs) 
        x = lhs.x + rhs.x
        y = lhs.y + rhs.y
        return Vector2D(x,y) 
        end,
    __sub = function (lhs, rhs) 
        x = lhs.x - rhs.x
        y = lhs.y - rhs.y
        return Vector2D(x,y) 
        end,
    __div = function (lhs, rhs) 
         if type(rhs) == 'number' then 
            x = lhs.x/rhs
            y = lhs.y/rhs
            return Vector2D(x,y)
          end    
        x = lhs.x/rhs.x
        y = lhs.y/rhs.y
        return Vector2D(x,y) 
        end,
    __mul = function (lhs,rhs)
        if type(rhs) == 'number' then 
            x = lhs.x*rhs
            y = lhs.y*rhs
            return Vector2D(x,y)
          end
        x = lhs.x*rhs.x
        y = lhs.y*rhs.y
        return Vector2D(x,y) 
        end,
    __call = function(a, op)
        if op == '.' then 
            return function(b) return self.productoPunto(b) end
        elseif op == 'x' then
            return function(b) return self.productoCruz(b) end
            end
        
        end
        
    }
    
    setmetatable(self, mt) -- use "mt" as the metatable
    
    self.type = 'Vector2D'
    
    return self
end

function lerp(a,b,t) return (1-t)*a + t*b end

RATIO = Vector2D()




function getCustomSeed(string_base)
    local i = 1
    local lens = string_base:len()+1
    if lens <= 1 then
        return os.time()
    end
    local string_number = '0'
    while i < lens do
        local char = string_base:sub(i,i)
        local char_byte = string.byte(char)
        if char_byte >= 48 and char_byte <= 57 then
           string_number = string_number..char
        else
           string_number = tostring(tonumber(string_number)+char_byte)
        end
        i = i+1
        
    end
    return tonumber(string_number)
end


function setCustomSeed(string_base)
   local seed = getCustomSeed(string_base)
   love.math.setRandomSeed( seed )
   math.randomseed(seed)
end

-- by Michal Kottman
function spairs(t, order)
    -- collect the keys
    local keys = {}
    for k in pairs(t) do keys[#keys+1] = k end

    -- if order function given, sort by it by passing the table and keys a, b,
    -- otherwise just sort the keys 
    if order then
        table.sort(keys, function(a,b) return order(t, a, b) end)
    else
        table.sort(keys)
    end

    -- return the iterator function
    local i = 0
    return function()
        i = i + 1
        if keys[i] then
            return keys[i], t[keys[i]]
        end
    end
end




function hsvToRgb(h, s, v)
  local r, g, b

  local i = math.floor(h * 6);
  local f = h * 6 - i;
  local p = v * (1 - s);
  local q = v * (1 - f * s);
  local t = v * (1 - (1 - f) * s);

  i = i % 6

  if i == 0 then r, g, b = v, t, p
  elseif i == 1 then r, g, b = q, v, p
  elseif i == 2 then r, g, b = p, v, t
  elseif i == 3 then r, g, b = p, q, v
  elseif i == 4 then r, g, b = t, p, v
  elseif i == 5 then r, g, b = v, p, q
  end

  return r * 255, g * 255, b * 255
end
