METABALL_LIST = {}
RESOLUCION = 48
CELL_SIZE = (720/RESOLUCION)
HEX = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}
TILES = {}

function metaBall(r,tipe)
    local self = {}
    self.x = math.random(720*0.35,720*0.65)
    self.y = math.random(720*0.35,720*0.45)
    self.vx = math.random(-2,2)
    self.vy = math.random(-2,2)
    self.radio = r
    self.tradio = self.radio/2
    self.tipe = tipe
    if tipe == 'line' then
        self.vx = self.vx*4
        self.vy = self.vy*4
    end
    self.busqueda = true
    self.inside = false
    function self.update()
        -- [[
        self.x = self.x+self.vx
        self.y = self.y+self.vy
        if self.x-self.radio < 40 then
            self.vx = -self.vx
            self.x = 720/2
            self.y = 720/2
        end
        if self.x+self.radio > 680 then
            self.vx = -self.vx
            self.x = 720/2
            self.y = 720/2
        end
        if self.y-self.radio < 40 then
            self.vy = -self.vy
            self.x = 720/2
            self.y = 720/2
        end
        if self.y+self.radio > 680 then
            self.vy = -self.vy
            self.x = 720/2
            self.y = 720/2
        end
        -- [[
        if self.tipe == 'fill' then
            local v = Vector2D(720/2-self.x,720/2-self.y)
            if  v.magnitud() > 10 then
                nv = v.normalizar()
                self.vx = nv.x*2
                self.vy = nv.y*2
            end
        end
        --]]
        self.inside = false
        local i = 1
        while METABALL_LIST[i] do
            local mt = METABALL_LIST[i]
            local v = Vector2D(mt.x-self.x,mt.y-self.y)
            local dif = v.magnitud()
            if  dif < (mt.tradio+self.tradio)  then
                nv = v.normalizar()
                mt.x = mt.x+nv.x*((mt.tradio+self.tradio)-dif)
                mt.y = mt.y+nv.y*((mt.tradio+self.tradio)-dif)
            end
            
            i=i+1
        end
    end
    
    function self.draw()
        if self.tipe == 'line' then
            love.graphics.setColor(0,0.1,0.7,0.5)
        else
			love.graphics.setColor(1,1,1)
			love.graphics.circle('line',self.x,self.y,self.tradio)
            love.graphics.setColor(0,0.1,0.5,0.5)
        end
        love.graphics.circle(self.tipe,self.x,self.y,self.tradio)
        --love.graphics.setColor(1,0,0)
        --love.graphics.circle('line',self.x,self.y,self.radio)
        --[[
        local i = 1
        while METABALL_LIST[i] do
            local mt = METABALL_LIST[i]
            if mt == self then
                love.graphics.print(string.format("ID: %d",i),self.x,self.y+(5))
            end
            i=i+1
        end
       --]]

    end

    return self
end

function initMetaballs(num)
    local i  = 0
    while i < num do
        table.insert(METABALL_LIST,metaBall(math.random(75,20),'fill'))
        i=i+1
    end
    i=0
    while i < num do
        table.insert(METABALL_LIST,metaBall(25,'line'))
        i=i+1
    end
    --METABALL_LIST[num].tractor = true
    i=0
    while i < 50 do
        j = 1
        while METABALL_LIST[j] do
            local mt = METABALL_LIST[j]
            mt.update()
            j=j+1
        end
        i=i+1
    end
end

function addMetaBall()
    table.insert(METABALL_LIST,metaBall(math.random(75,20),'fill'))
    table.insert(METABALL_LIST,metaBall(25,'line'))
    j = 1
    while METABALL_LIST[j] do
        local mt = METABALL_LIST[j]
        mt.update()
        j=j+1
    end
end

function removeMetaBall()
    table.remove(METABALL_LIST,#METABALL_LIST)
    table.remove(METABALL_LIST,#METABALL_LIST)
    j = 1
    while METABALL_LIST[j] do
        local mt = METABALL_LIST[j]
        mt.update()
        j=j+1
    end
end



function tile1()
    local self = {}
    function self.draw(x,y)
        local x1 = x+CELL_SIZE*0.5
        local y1 = y+CELL_SIZE
        local x2 = x
        local y2 = y+CELL_SIZE*0.5
        love.graphics.polygon('fill',x1,y1,x2,y2,x2,y1)
    end
    
    return self
end

function tile2()
    local self = {}
    function self.draw(x,y)
        local x1 = x+CELL_SIZE*0.5
        local y1 = y+CELL_SIZE
        local x2 = x+CELL_SIZE
        local y2 = y+CELL_SIZE*0.5
        love.graphics.polygon('fill',x1,y1,x2,y2,x2,y1)
    end
    
    return self
end

function tile3()
    local self = {}
    function self.draw(x,y)
        local x1 = x+CELL_SIZE
        local y1 = y+CELL_SIZE*0.5
        
        local x2 = x1
        local y2 = y+CELL_SIZE
        
        local x3 = x
        local y3 = y2
        
        local x4 = x3
        local y4 = y+CELL_SIZE*0.5
        
        love.graphics.polygon('fill', x1,y1, x2,y2, x3,y3,   x3,y3, x4,y4, x1,y1 )
        --love.graphics.line(x1,y1,x2,y2)
    end
    
    return self
end

function tile4()
    local self = {}
    function self.draw(x,y)
        local x1 = x+CELL_SIZE*0.5
        local y1 = y
        local x2 = x+CELL_SIZE
        local y2 = y+CELL_SIZE*0.5
        love.graphics.polygon('fill',x1,y1,x2,y2,x2,y1)
        --love.graphics.line(x1,y1,x2,y2)
    end
    
    return self
end

function tile5()
    local self = {}
    function self.draw(x,y)
        local x1 = x+CELL_SIZE*0.5
        local y1 = y
        local x2 = x+CELL_SIZE
        local y2 = y+CELL_SIZE*0.5
        
        local x3 = x+CELL_SIZE*0.5
        local y3 = y+CELL_SIZE
        local x4 = x
        local y4 = y+CELL_SIZE*0.5
        love.graphics.polygon('fill',x2,y1, x2,y2, x3,y3,x4,y3,x4,y4 ,x1,y1)
        --love.graphics.line(x2,y1, x2,y2, x3,y3,x4,y3,x4,y4 ,x1,y1)
    end
    
    return self
end

function tile6()
    local self = {}
    function self.draw(x,y)
        local x1 = x+CELL_SIZE*0.5
        local y1 = y
        
        local x2 = x1
        local y2 = y+CELL_SIZE
        
        local x3 = x+CELL_SIZE
        local y3 = y2
        
        local x4 = x3
        local y4 = y
        
        love.graphics.polygon('fill', x1,y1, x2,y2, x3,y3,   x3,y3, x4,y4, x1,y1 )
        --love.graphics.line(x1,y1,x2,y2)
    end
    
    return self
end

function tile7()
    local self = {}
    function self.draw(x,y)
        local x0 = x
        local y0 = y+CELL_SIZE
        local x1 = x
        local y1 = y+CELL_SIZE*0.5
        local x2 = x+CELL_SIZE*0.5
        local y2 = y
        local x3 = x+CELL_SIZE
        local y3 = y2
        local x4 = x3
        local y4 = y+CELL_SIZE
        love.graphics.polygon('fill',x0,y0, x1,y1, x2,y2,x3,y3, x4,y4, x0,y0) 
        --love.graphics.line(x0,y0, x1,y1, x2,y2,x3,y3, x4,y4, x0,y0)
    end
    
    return self
end

function tile8()
    local self = {}
    function self.draw(x,y)
        local x1 = x+CELL_SIZE*0.5
        local y1 = y
        local x2 = x
        local y2 = y+CELL_SIZE*0.5
        love.graphics.polygon('fill',x1,y1,x2,y1,x2,y2)
        --love.graphics.line(x1,y1,x2,y2)
    end
    
    return self
end

function tile9()
    local self = {}
    function self.draw(x,y)
        local x1 = x+CELL_SIZE*0.5
        local y1 = y
        
        local x2 = x1
        local y2 = y+CELL_SIZE
        
        local x3 = x
        local y3 = y2
        
        local x4 = x3
        local y4 = y
        
        love.graphics.polygon('fill', x1,y1, x2,y2, x3,y3,   x3,y3, x4,y4, x1,y1 )
        --love.graphics.line(x1,y1,x2,y2)
    end
    
    return self
end

function tileA()
    local self = {}
    function self.draw(x,y)
        local x1 = x+CELL_SIZE*0.5
        local y1 = y
        local x2 = x
        local y2 = y+CELL_SIZE*0.5
        
        local x3 = x+CELL_SIZE*0.5
        local y3 = y+CELL_SIZE
        local x4 = x+CELL_SIZE
        local y4 = y+CELL_SIZE*0.5
        love.graphics.polygon('fill',x2,y1, x2,y2, x3,y3,x4,y3,x4,y4 ,x1,y1)
        --love.graphics.line(x2,y1, x2,y2, x3,y3,x4,y3,x4,y4 ,x1,y1)
    end
    
    return self
end

function tileB()
    local self = {}
    function self.draw(x,y)
        local x0 = x+CELL_SIZE
        local y0 = y+CELL_SIZE
        local x1 = x+CELL_SIZE
        local y1 = y+CELL_SIZE*0.5
        local x2 = x+CELL_SIZE*0.5
        local y2 = y
        local x3 = x
        local y3 = y2
        local x4 = x3
        local y4 = y+CELL_SIZE
        love.graphics.polygon('fill',x0,y0, x1,y1, x2,y2,x3,y3, x4,y4, x0,y0) 
        --love.graphics.line(x0,y0, x1,y1, x2,y2,x3,y3, x4,y4, x0,y0)
    end
    
    return self
end

function tileC()
    local self = {}
    function self.draw(x,y)
        local x1 = x+CELL_SIZE
        local y1 = y+CELL_SIZE*0.5
        
        local x2 = x1
        local y2 = y
        
        local x3 = x
        local y3 = y2
        
        local x4 = x3
        local y4 = y+CELL_SIZE*0.5
        
        love.graphics.polygon('fill', x1,y1, x2,y2, x3,y3,   x3,y3, x4,y4, x1,y1 )
        --love.graphics.line(x1,y1,x2,y2)
    end
    
    return self
end

function tileE()
    local self = {}
    function self.draw(x,y)
        local x0 = x
        local y0 = y
        local x1 = x
        local y1 = y+CELL_SIZE*0.5
        local x2 = x+CELL_SIZE*0.5
        local y2 = y+CELL_SIZE
        local x3 = x+CELL_SIZE
        local y3 = y2
        local x4 = x3
        local y4 = y
        love.graphics.polygon('fill',x0,y0, x1,y1, x2,y2,x3,y3, x4,y4, x0,y0) 
        --love.graphics.line(x0,y0, x1,y1, x2,y2,x3,y3, x4,y4, x0,y0)
    end
    
    return self
end

function tileD()
    local self = {}
    function self.draw(x,y)
        local x0 = x+CELL_SIZE
        local y0 = y
        local x1 = x+CELL_SIZE
        local y1 = y+CELL_SIZE*0.5
        local x2 = x+CELL_SIZE*0.5
        local y2 = y+CELL_SIZE
        local x3 = x
        local y3 = y2
        local x4 = x3
        local y4 = y
        love.graphics.polygon('fill',x0,y0, x1,y1, x2,y2,x3,y3, x4,y4, x0,y0) 
        --love.graphics.line(x0,y0, x1,y1, x2,y2,x3,y3, x4,y4, x0,y0)
    end
    
    return self
end

function tileF()
    local self = {}
    function self.draw(x,y)
        local x0 = x
        local y0 = y
        local x1 = CELL_SIZE
        local y1 = CELL_SIZE
        love.graphics.rectangle('fill',x0,y0,x1,y1)
    end
    
    return self
end

TILES['1'] = tile1()
TILES['2'] = tile2()
TILES['3'] = tile3()
TILES['4'] = tile4()
TILES['5'] = tile5()
TILES['6'] = tile6()
TILES['7'] = tile7()
TILES['8'] = tile8()
TILES['9'] = tile9()
TILES['A'] = tileA()
TILES['B'] = tileB()
TILES['C'] = tileC()
TILES['D'] = tileD()
TILES['E'] = tileE()
TILES['F'] = tileF()


function canGetPoint(map,y,x)
    if map[y] then
        if map[y][x] then 
            return true
        end
    end
    return false
end

function renderMetaballs()
    local canvas = love.graphics.newCanvas(720,720)
    love.graphics.setCanvas(canvas)
    
    local table_buffer = {}
    love.graphics.setColor(1,1,1)
    
    i = 1
    while i <= RESOLUCION do
        j=1
        local tab = {}
        while j <= RESOLUCION do
            k=1
            local val = 0
            love.graphics.setColor(0.25,0.25,0.25)
            --love.graphics.rectangle('fill',((j)*scell),((i)*scell),scell-1,scell-1)
            
            while METABALL_LIST[k] do
                local mt = METABALL_LIST[k]
                if mt.tipe == 'fill' then
                    local v = Vector2D(mt.x-(j*CELL_SIZE),mt.y-(i*CELL_SIZE))
                    --labelTween:set()
                    val = val +  math.max((((mt.radio-v.magnitud())/mt.radio) ),0)
                end
                k=k+1
            end
            
            local tone = 0
            val = math.abs(val)
            if val > 0.4 then
                tone = val-0.3
                tone = inSine(tone, tone, 0.4, 1)
            end
            
            table.insert(tab,tone)
            
            j=j+1
        end
        table.insert(table_buffer,tab)
        i=i+1
    end
    
    i=1
    while table_buffer[i] do
        j=1
        while table_buffer[i][j] do
            val = 0.2
            local bit = 0
                if canGetPoint(table_buffer,i,j) then
                    if table_buffer[i][j] > 0 then 
                        bit = bxor(bit, 8)
                    end
                end
                if canGetPoint(table_buffer,i+1,j) then
                    if table_buffer[i+1][j] > 0 then 
                        bit = bxor(bit, 1)
                        val = lerp(val,table_buffer[i+1][j],0.5)
                    end
                end
                if canGetPoint(table_buffer,i,j+1) then
                    if table_buffer[i][j+1] > 0 then 
                        bit = bxor(bit, 4)
                        val = lerp(val,table_buffer[i][j+1],0.5)
                    end
                end
                if canGetPoint(table_buffer,i+1,j+1) then
                    if table_buffer[i+1][j+1] >0 then 
                        bit = bxor(bit, 2)
                        val = lerp(val,table_buffer[i+1][j+1],0.5)
                    end
                end
            
            if bit ~= 0 then 
                
                
                s = HEX[bit+1]
                
                love.graphics.setColor(val,val,val)
                --
                if TILES[s] then
                    TILES[s].draw(((j)*CELL_SIZE),((i)*CELL_SIZE))
                end
                
            end
            j=j+1
        end
        i=i+1
    end
    
    
    love.graphics.setCanvas()
    return canvas
end