
PRESSEDM = false

function checkBox(x,y,w,h,val)
    local self = {} 
    self.val = val
    self.x = x
    self.y = y
    self.w = w
    self.h = h
    function self.update()
        x, y = love.mouse.getPosition( )
        if (x > self.x and x < self.x+w) and (y > self.y and y < self.y+h) and  PRESSEDM then
            self.val = not self.val
            PRESSEDM = false
        end
    end
    function self.draw()
        if self.val then
            love.graphics.setColor(0,0,0)
            love.graphics.rectangle('fill',self.x,self.y,self.w,self.h)
            love.graphics.setColor(1,1,1)
            love.graphics.rectangle('line',self.x,self.y,self.w,self.h)
        else
            love.graphics.setColor(0.75,0.75,0.75)
            love.graphics.rectangle('line',self.x,self.y,self.w,self.h)
        end
    end
    return self
end

function Botton(x,y,w,h,texto,f)
    local self = {} 
    self.val = false
    self.x = x
    self.y = y
    self.w = w
    self.h = h
    self.f = f
    self.texto = texto
    self.over = false
    function self.update()
        x, y = love.mouse.getPosition( )
        self.over = false
        if (x > self.x and x < self.x+w) and (y > self.y and y < self.y+h) then
            self.over = true
            if PRESSEDM then
                self.val = true
            end
            if not PRESSEDM and self.val == true then
                self.f()
                self.val = false
            end
        else
            if not PRESSEDM and self.val then
                self.val = false
            end
        end
    end
    function self.draw()
        if not self.over then
            love.graphics.setColor(0,0,0)
            love.graphics.rectangle('fill',self.x,self.y,self.w,self.h)
            love.graphics.setColor(0.75,0.75,0.75)
            love.graphics.rectangle('line',self.x+1,self.y+1,self.w-2,self.h-2)
            love.graphics.setColor(0.75,0.75,0.75)
            love.graphics.print(self.texto,self.x+2,self.y+2)
        else
            if self.val then
                love.graphics.setColor(0.5,0.5,0.5)
                love.graphics.rectangle('fill',self.x,self.y,self.w,self.h)
                love.graphics.setColor(0.75,0.75,0.75)
                love.graphics.print(self.texto,self.x+2,self.y+2)
            else
                love.graphics.setColor(0.75,0.75,0.75)
                love.graphics.rectangle('fill',self.x,self.y,self.w,self.h)
                love.graphics.setColor(0,0,0)
                love.graphics.print(self.texto,self.x+2,self.y+2)
            end
        end
    end
    return self
end

function magicCheckButton(x,y,val)
    local self = checkBox(x,y,20,20,val)
    function self.draw()
        if not self.val then
            love.graphics.setColor(0.4,0.4,0.4,0.75)
            love.graphics.rectangle('fill',x,y,260,170)
            love.graphics.setColor(1,1,1)
            love.graphics.polygon('fill',x,y+5,x+10,y+15,x+20,y+5)
        else
            love.graphics.setColor(0,0,0,0.3)
            love.graphics.rectangle('fill',x,y,20,20)
            love.graphics.setColor(0.5,0.5,0.5)
            love.graphics.polygon('fill',x+8,y,x+12,y+8,x+8,y+16)
        end
    end
    return self
end


function sliderHandler(x,y,w,h)
    local self = {} 
    self.val = false
    self.x = x
    self.y = y
    self.w = w
    self.h = h
    self.over = false
    function self.draw()
        if not self.over then
            love.graphics.setColor(0,0,0)
            love.graphics.rectangle('fill',self.x-4,self.y,self.w,self.h)
        else
            if self.val then
                love.graphics.setColor(0.4,0.4,0.4)
                love.graphics.rectangle('fill',self.x-4,self.y,self.w,self.h)
            else
                love.graphics.setColor(0.65,0.65,0.65)
                love.graphics.rectangle('fill',self.x-4,self.y,self.w,self.h)
            end
        end
    end
    return self
end


function sliderH(x,y,w,h,min,max)
    local self = {}
    self.x = x
    self.y = y
    self.w = w
    self.h = h
    self.handler = sliderHandler(x,y-2,8,h+5)
    self.over = false
    self.val = 0
    
    self.min_w = self.x+5
    self.max_w = self.x+self.w-5
    self.max_v = self.max_w-self.min_w
    
    self.min_val = min
    self.max_val = max
    function self.setDefaultVal(val)
        self.handler.x = math.floor(lerp(self.min_w,self.max_w, val/self.max_val ))
        local act_v = self.handler.x-self.x-5
        self.val = lerp(self.min_val,self.max_val,act_v/self.max_v)
    end
    
    function self.setDefaultPercent(val)
        self.handler.x = math.floor(lerp(self.min_w,self.max_w,val))
        local act_v = self.handler.x-self.x-5
        self.val = lerp(self.min_val,self.max_val,act_v/self.max_v)
    end
    
    function self.update()
        x, y = love.mouse.getPosition( )
        self.over = false
        if (x > self.x and x < self.x+w) and (y > self.y and y < self.y+h) then
            self.over = true
            if PRESSEDM then
                self.handler.x = x
            end
        end
        self.handler.x = math.min(math.max(self.min_w,self.handler.x),self.max_w )
        local act_v = self.handler.x-self.x-5
        self.val = lerp(self.min_val,self.max_val,act_v/self.max_v)
        self.handler.over = self.over
    end
    function self.draw()
        if not self.over then
            love.graphics.setColor(0.45,0.45,0.45)
            love.graphics.rectangle('fill',self.x,self.y,self.w,self.h)
        else
            love.graphics.setColor(0,0,0)
            love.graphics.rectangle('fill',self.x,self.y,self.w,self.h)
        end
        self.handler.draw()
    end
    return self
end


