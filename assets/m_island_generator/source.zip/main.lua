love.filesystem.load("core.lua")()
love.filesystem.load("metaballs.lua")()
love.filesystem.load("dirty_gui.lua")()

io.stdout:setvbuf("no")

local major, minor, revision, codename = love.getVersion( )
local LEFT_M_BUTTON = 'l'
if major >= 0 then
   if minor > 9 then 
       LEFT_M_BUTTON = 1
   end
end

function inSine(t, b, c, d) return -c * math.cos(t / d * (math.pi / 2)) + c + b end
love.window.setTitle("Island Generator")
love.window.setMode(720,720)
HIDE = false
HIDE_METABALLS = false
PAUSE_METABALLS = true
HIDE_GRID = false
OFFSET_NOISE_X = 0
OFFSET_NOISE_Y = 0


function smoothIma(data_fuente)
    
    local a = math.random(10,90)
    local max = 0
    local min = 0
    local data_buffer = love.image.newImageData(720,720)
    
    i  = 0
    while i < RESOLUCION do
        local j = 0
        local t = {}
        while j < RESOLUCION do
            --local toneb = data_fuente:getPixel(i, j) -- solo nesesito el canal r
            local up = 0
            local down = 0
            local left = 0
            local right = 0
            if (i+1)*CELL_SIZE < 720 then down = data_fuente:getPixel((i+1)*CELL_SIZE,j) end
            if (i-1)*CELL_SIZE > 0 then up = data_fuente:getPixel((i-1)*CELL_SIZE,j*CELL_SIZE) end
            if (j+1)*CELL_SIZE < 720 then right = data_fuente:getPixel(i*CELL_SIZE,(j+1)*CELL_SIZE) end
            if (j-1)*CELL_SIZE > 0 then left = data_fuente:getPixel(i*CELL_SIZE,(j-1)*CELL_SIZE) end
            
            local v_a = lerp(down,up,0.5)
            local v_b = lerp(right,left,0.5)
            local v_c = lerp(v_a,v_b,0.5) 
            local tone = lerp(v_c,0,0.5)
            tone = math.min(math.pow(tone,0.35),1)
            min = math.min(tone,min)
            max = math.max(tone,max)
            data_buffer:setPixel(i, j, tone,tone,tone,tone)
            
            j=j+1
        end
        i=i+1
    end
    
    local canvas = love.graphics.newCanvas(720,720)
    local img_base = love.graphics.newImage(data_fuente)
    local img = love.graphics.newImage(data_buffer)
    love.graphics.setCanvas(canvas)
    love.graphics.setColor(1,1,1,1)
    love.graphics.draw(img_base,0,0,0,CELL_SIZE,CELL_SIZE)
    love.graphics.draw(img,0,0,0,CELL_SIZE,CELL_SIZE)
    love.graphics.draw(img,0,0,0,CELL_SIZE,CELL_SIZE)
    love.graphics.setCanvas()
    return canvas
end

function relieve(data_fuente)
    
    local a = math.rad(1)
    local max = 0
    local min = 0
    local offset_x = OFFSET_NOISE_X
    local offset_y = OFFSET_NOISE_Y
    
    i  = 0
    while i < 720 do
        local j = 0
        local t = {}
        while j < 720 do
                local r,g,b,a = data_fuente:getPixel(i,j)
                
                tone = 0
                if a > 0 then
                    tone = love.math.noise((j+offset_x)/128,(i+offset_y)/128)
                    tone = tone+love.math.noise((j+offset_x)/64,(i+offset_y)/64)*0.5
                    tone = tone+love.math.noise((j+offset_x)/32,(i+offset_y)/32)*0.25
                    tone = tone+love.math.noise((j+offset_x)/16,(i+offset_y)/16)*0.15
                    --tone = lerp(tone,love.math.noise((j+offset_x),(i+offset_y))*0.5,0.01)
                    --tone =  math.pow(tone,0.5)
                    tone = 1.1-(tone/1.5)
                    
                    tone = lerp(tone,r,1-a)
                    
                end
                tone = math.floor(tone*10)/10
                data_fuente:setPixel(i, j,tone,tone,tone,1)
                
            j=j+1
        end
        i=i+1
    end

    local canvas = love.graphics.newCanvas(720,720)
    local img = love.graphics.newImage(data_fuente)
    love.graphics.setCanvas(canvas)
    love.graphics.setColor(1,1,1,1)
    love.graphics.draw(img,0,0,0)
    love.graphics.setCanvas()
    return canvas
end

NIEVE = {1,1,1}
TUNDRA = {0.8,0.8,0.8}
SELVA  = {0.1,0.5,0.1}
PRADERA  = {0.0,0.8,0.0}
BOSQUE   = {0.0,0.6,0.1}
BOSQUE2   = {0.1,0.3,0.0}
DESIERTO = {1,0.8,0.5}

BIOMA_DIAGRAM = {
    {DESIERTO,DESIERTO,DESIERTO,SELVA,SELVA,SELVA},
    {DESIERTO,DESIERTO,PRADERA,SELVA,SELVA,SELVA},
    {DESIERTO,PRADERA,PRADERA,PRADERA,PRADERA,PRADERA},
    {PRADERA,BOSQUE,BOSQUE,BOSQUE,BOSQUE,BOSQUE},
    {TUNDRA,BOSQUE2,BOSQUE2,BOSQUE2,BOSQUE2,BOSQUE2},
    {TUNDRA,TUNDRA,TUNDRA,TUNDRA,TUNDRA,TUNDRA},
    {TUNDRA,TUNDRA,NIEVE,NIEVE,NIEVE,NIEVE},
    }

function biomas(data_fuente)
    
    local a = math.rad(1)
    local max = 0
    local min = 0
    local offset_x = OFFSET_NOISE_Y
    local offset_y = OFFSET_NOISE_X
    
    local data_buffer = love.image.newImageData(720,720)
    i  = 0
    while i < 720 do
        local j = 0
        local t = {}
        while j < 720 do
            local r,g,b,a = data_fuente:getPixel(i,j)
                if r > 0 then
                    -- [[
                    local A = (0.5*math.sin(math.rad((130+((720-j)*180/720))))+0.8)
                    A = A+(0.5*math.sin(math.rad((180+(i*180/720))))+0.8) --(math.sin(math.rad(180+(i*180/1200)))+tone+1)/2
                    --A = math.min( math.floor(((A)*11))/11-0.1, 1)
                    
                    A = lerp(A,(math.sin(math.rad((180+(i*180/OFFSET_NOISE_Y))))+1.5),0.01)
                    A = lerp(A,(0.2*math.sin(20*math.rad((180+(j*180/OFFSET_NOISE_X))))+1.5),0.001)
                    A = 1.3-(A*20/20)
                    
                    A = A+r*0.12 --las zonas más elevadas son las mas frias
                    A = 1-math.max(math.min(A-love.math.noise((j+offset_x)/128,(i+offset_y)/128)*0.15,1),0)
                    A = math.floor(A*6)/6 --temperaturas
                    if r > 0.9 then A = 0.5 end
                    -- [[
                    local B = love.math.noise((j+offset_x)/128,(i+offset_y)/128)
                    B = B+love.math.noise((i+offset_x)/64,(j+offset_y)/64)*0.5
                    B = B+love.math.noise((i+offset_x)/32,(j+offset_y)/32)*0.25
                    B = B+love.math.noise((i+offset_x)/16,(j+offset_y)/16)*0.15
                    --tone = lerp(tone,love.math.noise((j+offset_x),(i+offset_y))*0.5,0.01)
                    --tone =  math.pow(tone,0.5)
                    B = 2.1-(B/1.5)
                    B = math.min(math.floor(B*5)/5,1) --humedad
                    --B = lerp(A,B,0.2)
                     local tone = 0
                    if r > 0.6 then 
                        tone= BIOMA_DIAGRAM[7][6]
                    else
                        tone= BIOMA_DIAGRAM[7-math.floor(A*6)][7-math.floor(B*5)]
                    end
                    data_buffer:setPixel(i, j,tone[1],tone[2],tone[3])
                    --data_buffer:setPixel(i, j,A,A,A)
                else
                  data_buffer:setPixel(i, j,0,0,0.8,1)
                end
            j=j+1
        end
        i=i+1
    end
    print(min,max)
    local canvas = love.graphics.newCanvas(720,720)
    local img = love.graphics.newImage(data_buffer)
    local img_base = love.graphics.newImage(data_fuente)
    love.graphics.setCanvas(canvas)
    love.graphics.setColor(1,1,1,1)
    love.graphics.draw(img_base,0,0,0)
    love.graphics.setColor(1,1,1,0.5)
    love.graphics.draw(img,0,0,0)
    love.graphics.setCanvas()
    return canvas
end



CANVAS = nil

function love.load()
   
   setCustomSeed(tostring(os.time()))
   --love.graphics.setDefaultFilter('nearest','nearest',1)
    --meta = love.graphics.newSpriteBatch(ima,2000)
    initMetaballs(25)
    CANVAS = renderMetaballs()
end

function newLandMass()
    CANVAS = renderMetaballs()   
end

function addElevation()
    CANVAS = smoothIma(CANVAS:newImageData( ))
    CANVAS = relieve(CANVAS:newImageData( ))
end

function addBiomas()
    CANVAS = biomas(CANVAS:newImageData( ))
end

function love.keypressed(key)
    if key == "escape" then
        love.event.quit()
    end
	if key == 'p' then
		PAUSE_METABALLS = not PAUSE_METABALLS
	end
end


CHOSE_BALL = 0
function love.mousepressed(x, y, button, istouch)
   if button == 1 then -- Versions prior to 0.10.0 use the MouseConstant 'l'
      PRESSEDM = true
   end
end

function love.mousereleased(x, y, button, istouch)
   if button == 1 then -- Versions prior to 0.10.0 use the MouseConstant 'l'
      printx = x
      printy = y
      PRESSEDM = false
   end
end



radio_fallout = 1
h = magicCheckButton(0,0,HIDE)

a = checkBox(110,40,13,13,HIDE_METABALLS)
b = checkBox(110,20,13,13,PAUSE_METABALLS)
c = checkBox(110,60,13,13,HIDE_GRID)

slider = sliderH(140,90,100,10,16,80)
slider.setDefaultPercent(0.5)
slider_balls = sliderH(140,110,100,10,25,50)
slider_n_off_x = sliderH(140,130,100,10,0,1000)
slider_n_off_y = sliderH(140,150,100,10,0,1000)
slider_n_off_x.setDefaultVal(500)
slider_n_off_y.setDefaultVal(500)

boton = Botton(140,18,100,18,'Form Landmass',newLandMass)
boton2 = Botton(140,38,100,18,'  Add elevation ',addElevation)
boton3 = Botton(140,58,100,18,'   Add biomes ',addBiomas)

previus_pause = false
local t = 0

function love.update(dt)
	if dt < 1/60 then
        love.timer.sleep((1-dt)/60)
    end
	
	  local ancho = love.graphics.getWidth()
	  local alto = love.graphics.getHeight()
	  RATIO.x = (ancho/1280) or 1
	  RATIO.y = (alto/720) or 1
	  
	 h.update()
	  
	 if not PAUSE_METABALLS then 
		i = 1
		while METABALL_LIST[i] do
			local mt = METABALL_LIST[i]
			mt.update()
			i=i+1
		end
	 end
		--]]
	if not HIDE then
		a.update()
		b.update()
		c.update()
		boton.update()
		boton2.update()
		boton3.update()
		slider.update()
		slider_balls.update()
		slider_n_off_x.update()
		slider_n_off_y.update()
	end

	HIDE_METABALLS = a.val
	PAUSE_METABALLS = b.val
	HIDE_GRID = c.val
	HIDE = h.val
	RESOLUCION = math.floor(slider.val)
	CELL_SIZE = (720/RESOLUCION)
	OFFSET_NOISE_X = slider_n_off_x.val
	OFFSET_NOISE_Y = slider_n_off_y.val

	local ball_number = math.floor(slider_balls.val)
	if ball_number*2 ~= #METABALL_LIST then
		if ball_number*2 < #METABALL_LIST then
			while ball_number*2 < #METABALL_LIST do
				removeMetaBall()
			end
		end
		if ball_number*2 > #METABALL_LIST then
			while ball_number*2 > #METABALL_LIST do
				addMetaBall()
			end
		end
	end
end


function love.draw()
	love.graphics.setBackgroundColor(0,0,0,1)
	love.graphics.setLineWidth(1)
	--love.graphics.setBlendMode('add')
	love.graphics.setColor(1,1,1)
	love.graphics.draw(CANVAS)
	
	-- [[
	if not HIDE_METABALLS then
		i = 1
		while METABALL_LIST[i] do
			METABALL_LIST[i].draw()
			i=i+1
		end
	end
	
	local tone_grid = 1-(math.floor(slider.val)/100)
	love.graphics.setColor(0.5,0.5,0.5,tone_grid)
	if not HIDE_GRID then
		i = 1
		while i <= RESOLUCION do
			love.graphics.line(0,i*CELL_SIZE,j*CELL_SIZE,i*CELL_SIZE)
			i=i+1
		end
		j=1
		while j <= RESOLUCION do
			love.graphics.line(j*CELL_SIZE,0, j*CELL_SIZE,i*CELL_SIZE)
			j=j+1
		end
	end
	
	h.draw()
	
	if not HIDE then
		love.graphics.setColor(0,0,0)
		love.graphics.print('Pause the balls',10,20)
		love.graphics.print('Hide the balls',10,40)
		love.graphics.print('Hide the grid ',10,60)
		love.graphics.print('Grid resolution:'..tostring(math.floor(slider.val)),10,90)
		love.graphics.print('Number of balls:'..tostring(math.floor(slider_balls.val)),10,110)
		love.graphics.print('Noise Offset X: '..tostring(math.floor(slider_n_off_x.val)),10,130)
		love.graphics.print('Noise Offset Y: '..tostring(math.floor(slider_n_off_y.val)),10,150)
		--love.graphics.print('Use P to pause/play',0,15)
		--love.graphics.print('Use SPACE to generate a landmass',0,30)
		a.draw()
		b.draw()
		c.draw()
		boton.draw()
		boton2.draw()
		boton3.draw()
		slider.draw()
		slider_balls.draw()
		slider_n_off_x.draw()
		slider_n_off_y.draw()
	end

end
