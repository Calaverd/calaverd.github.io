<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="tile_map" tilewidth="16" tileheight="16" tilecount="5" columns="5">
 <image source="tile_map.png" width="80" height="16"/>
</tileset>
