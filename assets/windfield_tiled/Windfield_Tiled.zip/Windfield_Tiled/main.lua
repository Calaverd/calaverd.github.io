--load windfield
wf = require 'windfield'
local world = nil
local map_sprite_batch = nil

love.window.setMode(512,512)
love.window.setTitle('Windfield x Tiled')

--This is a helper function to make more simple create the quads from a tilemap
function makeQuads(ima_width,ima_height,quad_width,quad_height)
    local list = {}
    local rows = math.floor(ima_height/quad_height)
    local columns = math.floor(ima_width/quad_width)
    
    offset_x = offset_x or 0
    offset_y = offset_y or 0

    --print(rows,columns)
    local count = 1
    local i = 0
    while i < rows do
        local j = 0
        while j < columns do
            local x = (quad_width*j)+offset_x
            local y = (quad_height*i)+offset_y
            list[count] = love.graphics.newQuad(x,y,quad_width,quad_height,ima_width, ima_height)
            count = count+1
            j = j+1
        end
        i=i+1
    end
    return list
end

function love.load()
	-- Create the world 
	world = wf.newWorld(0,0,true)
	
	-- Load our tilemap
	local temp_map = love.filesystem.load('tile_map.lua')()
	local MAP_w = temp_map.width
	local MAP_h = temp_map.height
	local TILE_SIZE = 16
	
	-- This fragment is for loading and drawing the tile map,
	-- We use a sprite batch
	local image = love.graphics.newImage('tile_map.png')
	--we gonna need this to get the tile to use...
	local quad_list = makeQuads(image:getWidth(),image:getHeight(), TILE_SIZE, TILE_SIZE)
	map_sprite_batch = love.graphics.newSpriteBatch( image, MAP_w * MAP_h )
	
	
	-- a list for your colliders...
	local   list_of_colliders = {}
	
	
	-- I could have used "for _,layer on  ipairs(temp_map.layers) do"
	-- instead of while. I just like more to use while loops.
	local layer_num = 1
	local layer = temp_map.layers[layer_num]
	while layer do
    	--[[
        	I will make the following assuptions:
        		*On your map, the collision layer is named as 'collition'
        		*All space that is free (no tile put) has not collistion
    	]]
    	if layer.name == 'collition' then
        	local y = 0
        	while y < MAP_h do
            	local x = 0
            	while x < MAP_w do
                	-- because the generated lua file, puts all the tiles on one dimentional table
                	-- we must transform from x,y to 1d ids 
                	local tile_id = (y*MAP_w )+x+1
                	local tile = layer.data[tile_id] --get the tile value
                	--tiled puts 0 on empty spaces.
                	io.write(tostring(tile))
                	if tile > 0 then 
                    	-- Create the collider, and add it to a list.
                    	-- we multiply x and y for the size of the tile to get the position on the world,
                    	-- the width and height are equal to the size of our tiles.
                    	table.insert(list_of_colliders, world:newRectangleCollider(x*TILE_SIZE, y*TILE_SIZE, TILE_SIZE-1, TILE_SIZE-1) )
                	end
                	
                	x=x+1
            	end
            	print()
            	y=y+1
        	end
    	end
    	
    	if layer.type == "objectgroup" then
    		for _,object in ipairs(layer.objects) do
    			if object.shape == 'rectangle' then
    				table.insert(list_of_colliders, world:newRectangleCollider(object.x, object.y, object.width , object.height ) )
    			end
    			if object.shape == 'polygon' then
    				-- calculate the vertices
    				local new_vertices = {}
    				for _,vertex in ipairs(object.polygon) do
    					vertex.x = object.x + vertex.x
    					vertex.y = object.y + vertex.y
    					table.insert(new_vertices, vertex.x)
    					table.insert(new_vertices, vertex.y)
    				end
    				table.insert(list_of_colliders,world:newPolygonCollider(new_vertices))
    			end
    		end
    	end
    	
    	-- BONUS, load also the pictures, in this case, is the first layer
    	-- can also be called by their name 'tilemap'
    	if layer_num == 1 then
        	local y = 0
        	while y < MAP_h do
            	local x = 0
            	while x < MAP_w do
                	-- because the generated lua file, puts all the tiles on one dimentional table
                	-- we must transform from x,y to 1d ids 
                	local tile_id = (y*MAP_w )+x+1
                	local tile = layer.data[tile_id] --get the tile value
                	--tiled puts 0 on empty spaces.
                	if tile > 0 then 
                    	-- Add tho the sprite batch
                    	map_sprite_batch:add(quad_list[tile], x*TILE_SIZE, y*TILE_SIZE)
                	end
                	
                	x=x+1
            	end
            	y=y+1
        	end
    	end
    	
    	
    	--go to the next layer
    	layer_num = layer_num+1
    	layer = temp_map.layers[layer_num]
	end
end

function love.update(dt)
	world:update(dt)
end

function love.draw()
	love.graphics.draw(map_sprite_batch)
	world:draw()
end
