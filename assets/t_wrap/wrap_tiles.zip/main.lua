love.window.setTitle("Test Love2D Image Wrap")
love.window.setMode(512,570)

local love_wrap_modes = {
    'clampzero',
    'clamp',
    'repeat',
    'mirroredrepeat'
    }
    
local horizontal_wrap = love_wrap_modes[1]
local vertical_wrap = love_wrap_modes[1] 
local tilemap = nil
local tile_data = nil
local tile_image = nil
local quad = nil

local h_t = 1 --horizontal_wrap control counter
local v_t = 1 --vertical_wrap control counter

function love.load()
    tilemap = love.image.newImageData('Overworld.png')
    tile_data = love.image.newImageData(16,16)
    

    tile_data:paste(
        tilemap, -- Draw from this image data 
        0,0,     -- To the other data starting from this point
        80,160,  -- A chunk of the tile map that starts here
        16,16    -- And goes for 16 pixels wide and tall.
        )
    
    tile_image = love.graphics.newImage(tile_data)
    tile_image:setFilter('nearest','nearest')
    tile_image:setWrap(horizontal_wrap,vertical_wrap)  
    
    quad = love.graphics.newQuad(
        -56, -56, -- start point (x,y) of the quad, yes, it can be negative.
        128, 128, -- size of the quad
         16,  16  -- size of the image
         )
end

function love.update(dt)
    if dt < 1/60 then
        love.timer.sleep(dt-1/60)
    end
end

function love.draw()
    love.graphics.setBackgroundColor(0.75,0.75,0.75)
    love.graphics.setColor(1,1,1)
    love.graphics.draw(tile_image,quad,0,0,0,4,4) --scaled x4
    
    love.graphics.setColor(0,0,0)
    love.graphics.rectangle('line',0,0,128*4,128*4)    
    
    love.graphics.printf('Horizontal Wrap: "'..horizontal_wrap..'"',0,515,255,'center')
    love.graphics.printf('Use LEFT/A and RIGHT/D keys to change the horizontal wrap mode',0,535,255,'center')
    
    love.graphics.printf('Vertical Wrap: "'..vertical_wrap..'"',255,515,255,'center')
    love.graphics.printf('Use UP/W and DOWN/S keys to change the vertical wrap mode',255,535,255,'center')
    
end

function love.keypressed(key)
    if key == 'w' or key == 'up' then
        v_t = v_t-1
        if v_t <= 0 then v_t = #love_wrap_modes end 
    end
    if key == 's' or key == 'down' then
        v_t = v_t+1
        if v_t > #love_wrap_modes then v_t = 1 end
    end
    
    if key == 'a' or key == 'left' then
        h_t = h_t-1
        if h_t <= 0 then h_t = #love_wrap_modes end 
    end
    if key == 'd' or key == 'right' then
        h_t = h_t+1
        if h_t > #love_wrap_modes then h_t = 1 end
    end
    
    if key == 'd' or key == 'right' then
        h_t = h_t+1
        if h_t > #love_wrap_modes then h_t = 1 end
    end
    
    horizontal_wrap = love_wrap_modes[h_t]
    vertical_wrap = love_wrap_modes[v_t] 
    tile_image:setWrap(horizontal_wrap,vertical_wrap)
end
